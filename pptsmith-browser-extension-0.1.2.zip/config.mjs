export const SITE_ORIGIN = 'https://ppt.skillmelody.com';
export const PROTOCOL = 1;
