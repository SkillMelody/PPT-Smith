(() => {
  if(globalThis.__pptsmithCapture)return;
  globalThis.__pptsmithCapture=true;
  let cancelCurrent;
  chrome.runtime.onMessage.addListener((message,sender,reply)=>{
    if(sender.id!==chrome.runtime.id||message?.type!=='capture:start')return;
    cancelCurrent?.();
    const zh=message.lang!=='en', host=document.createElement('div');host.id='pptsmith-capture-overlay';
    host.style.cssText='all:initial;position:fixed;inset:0;z-index:2147483647;';
    const root=host.attachShadow({mode:'closed'});
    root.innerHTML=`<style>:host{all:initial}.overlay{position:fixed;inset:0;cursor:crosshair;background:#101b3122;font:13px/1.5 system-ui;color:#fff;touch-action:none}.hint{position:absolute;top:20px;left:50%;transform:translateX(-50%);padding:10px 16px;background:#17263d;border-radius:7px;white-space:nowrap;pointer-events:none}.rect{position:absolute;border:2px solid #93baff;box-shadow:0 0 0 10000px #101b3170;pointer-events:none}.tools{position:absolute;display:flex;align-items:center;gap:6px;background:#fff;color:#15243d;border-radius:7px;box-shadow:0 5px 25px #15243d44;padding:5px;font-size:11px;cursor:default}.tools span{padding:0 6px}.tools button{font:inherit;padding:9px 11px;cursor:pointer;background:#fff;color:#15243d;border:0;border-radius:4px}.tools button:last-child{background:#1957e8;color:#fff}.tools button:focus-visible{outline:2px solid #1957e8;outline-offset:2px}</style><div class="overlay"><div class="hint">${zh?'拖动框选要收集的区域 · Esc 取消':'Drag to select an area · Esc to cancel'}</div></div>`;
    const overlay=root.querySelector('.overlay');let start,rect,selection;
    const previousFocus=document.activeElement;overlay.tabIndex=-1;
    overlay.addEventListener('wheel',e=>e.preventDefault(),{passive:false});
    const send=(type,extra={})=>chrome.runtime.sendMessage({type,token:message.token,...extra}).catch(()=>{});
    function finish(cancel=true){host.remove();document.removeEventListener('keydown',key,true);cancelCurrent=null;previousFocus?.focus?.({preventScroll:true});if(cancel)send('capture:cancel');}
    function key(e){if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();finish();}else if(['ArrowUp','ArrowDown','PageUp','PageDown','Home','End',' '].includes(e.key))e.preventDefault();}
    cancelCurrent=()=>finish();document.addEventListener('keydown',key,true);document.documentElement.append(host);overlay.focus({preventScroll:true});
    overlay.onpointerdown=e=>{if(e.target.closest('.tools'))return;e.preventDefault();root.querySelector('.tools')?.remove();rect?.remove();start={x:e.clientX,y:e.clientY};rect=document.createElement('div');rect.className='rect';overlay.append(rect);overlay.setPointerCapture(e.pointerId);};
    overlay.onpointermove=e=>{if(!start)return;const x=Math.max(0,Math.min(innerWidth,e.clientX)),y=Math.max(0,Math.min(innerHeight,e.clientY));selection={x:Math.min(x,start.x),y:Math.min(y,start.y),width:Math.abs(x-start.x),height:Math.abs(y-start.y)};Object.assign(rect.style,Object.fromEntries(Object.entries(selection).map(([k,v])=>[k==='x'?'left':k==='y'?'top':k,`${v}px`])));};
    overlay.onpointerup=e=>{if(!start)return;start=null;if(!selection||selection.width<8||selection.height<8){rect?.remove();return;}const tools=document.createElement('div');tools.className='tools';tools.style.left=`${Math.max(8,Math.min(innerWidth-290,selection.x+selection.width-290))}px`;tools.style.top=`${Math.min(innerHeight-55,selection.y+selection.height+8)}px`;tools.innerHTML=`<span>${Math.round(selection.width)} × ${Math.round(selection.height)}</span><button>${zh?'取消':'Cancel'}</button><button>${zh?'加入资料篮':'Add to basket'}</button>`;const buttons=tools.querySelectorAll('button');buttons[0].onclick=()=>finish();buttons[1].onclick=()=>{send('capture:finish',{rect:selection,viewport:{width:innerWidth,height:innerHeight},title:document.title.slice(0,1000),sourceUrl:location.href});finish(false);};overlay.append(tools);buttons[1].focus();};
    reply({ok:true});
  });
})();
