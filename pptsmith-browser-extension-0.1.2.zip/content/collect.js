(() => {
  if (globalThis.__pptsmithCollector) return;
  globalThis.__pptsmithCollector = true;
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (sender.id !== chrome.runtime.id || !['collect:article','collect:image'].includes(message?.type)) return;
    try {
      const common={title:document.title.slice(0,1000),sourceUrl:location.href,capturedAt:new Date().toISOString()};
      if(message.type==='collect:article'){
        const parsed=new Readability(document.cloneNode(true),{maxElemsToParse:100000,charThreshold:80}).parse();
        const text=parsed?.textContent?.trim();
        if(!text)throw new Error('NO_ARTICLE');
        if(text.length>1_000_000)throw new Error('CHARACTER_LIMIT');
        reply({ok:true,item:{...common,type:'article',title:(parsed.title||document.title).slice(0,1000),text}});
      }else{
        const img=[...document.images].find(el=>el.currentSrc===message.srcUrl||el.src===message.srcUrl);
        if(!img || !img.complete || !img.naturalWidth)throw new Error('IMAGE_UNAVAILABLE');
        const rect=img.getBoundingClientRect();
        let dataUrl=null;
        try {
          if(img.naturalWidth*img.naturalHeight>40_000_000)throw new Error('IMAGE_TOO_LARGE');
          const canvas=document.createElement('canvas');canvas.width=img.naturalWidth;canvas.height=img.naturalHeight;
          canvas.getContext('2d').drawImage(img,0,0);dataUrl=canvas.toDataURL('image/png');
        }catch{/* Cross-origin images can instead be collected from visible pixels. */}
        if(!dataUrl && (rect.left<0||rect.top<0||rect.right>innerWidth||rect.bottom>innerHeight||rect.width<1||rect.height<1))throw new Error('IMAGE_NEEDS_VISIBLE_CAPTURE');
        reply({ok:true,item:{...common,type:'image',title:(img.alt||document.title).slice(0,1000)},dataUrl,rect:{x:rect.x,y:rect.y,width:rect.width,height:rect.height},viewport:{width:innerWidth,height:innerHeight}});
      }
    }catch(error){reply({ok:false,errorCode:error.message==='NO_ARTICLE'?'NO_ARTICLE':error.message});}
  });
})();
