(() => {
  const origins=chrome.runtime.getManifest().content_scripts[0].matches.map(pattern=>new URL(pattern).origin);
  if(!origins.includes(location.origin)||window.top!==window)return;
  const origin=location.origin;
  window.addEventListener('message',event=>{
    if(event.source!==window||event.origin!==origin||!event.data||typeof event.data!=='object')return;
    const data=event.data;
    if(data.type==='pptsmith:status'){
      chrome.runtime.sendMessage({type:'bridge:status',data:{balance:data.balance,hasCode:data.hasCode,purchaseUrl:data.purchaseUrl,purchaseUrls:data.purchaseUrls}}).catch(()=>{});
      return;
    }
    const nonce=new URL(location.href).searchParams.get('handoff');
    if(!nonce||data.handoff!==nonce)return;
    if(data.type==='pptsmith:handoff-ready'){
      chrome.runtime.sendMessage({type:'bridge:ready',handoff:nonce,protocol:data.protocol,features:Array.isArray(data.features)?data.features.filter(f=>f==='image-sources-v1'):[]}).then(result=>{
        if(result?.ok&&result.payload)window.postMessage({type:'pptsmith:handoff-payload',...result.payload},origin);
      }).catch(()=>{});
    }else if(data.type==='pptsmith:handoff-done'){
      chrome.runtime.sendMessage({type:'bridge:done',handoff:nonce,protocol:data.protocol,ok:data.ok,errorCode:data.errorCode,status:{balance:data.balance,hasCode:data.hasCode,purchaseUrl:data.purchaseUrl,purchaseUrls:data.purchaseUrls}}).catch(()=>{});
    }
  });
})();
