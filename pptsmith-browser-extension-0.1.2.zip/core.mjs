export const MAX_CHARACTERS = 1_000_000;
export const MAX_IMAGE_BYTES = 20 * 1024 * 1024;
export const MAX_SOURCE_IMAGES = 4;
export const MAX_HANDOFF_IMAGE_BYTES = 14 * 1024 * 1024;
export const PROTOCOL = 1;
export class ExtensionError extends Error {
  constructor(code, message = code) {super(message); this.code = code;}
}
export function validSourceUrl(value) {
  try {const u = new URL(value); return ['https:', 'http:'].includes(u.protocol) && !u.username && !u.password;} catch {return false;}
}
export function validatePayload(value, expectedNonce) {
  if (!value || value.protocol !== PROTOCOL) throw new ExtensionError('PROTOCOL_MISMATCH');
  if (typeof value.handoff !== 'string' || !/^[A-Za-z0-9_-]{20,128}$/.test(value.handoff) || value.handoff !== expectedNonce) throw new ExtensionError('HANDOFF_INVALID');
  if (!['template','create'].includes(value.route) || typeof value.requirement !== 'string' || value.requirement.length > MAX_CHARACTERS || !Array.isArray(value.items) || !value.items.length || value.items.length > 1000) throw new ExtensionError('PAYLOAD_INVALID');
  const items = value.items.map(item => {
    if (!item || !['article','text','image'].includes(item.type) || typeof item.title !== 'string' || item.title.length > 1000 || !validSourceUrl(item.sourceUrl) || item.sourceUrl.length > 8000 || typeof item.capturedAt !== 'string' || !Number.isFinite(Date.parse(item.capturedAt))) throw new ExtensionError('PAYLOAD_INVALID');
    if(item.type==='image'){
      if(typeof item.data!=='string'||item.data.length>Math.ceil(MAX_HANDOFF_IMAGE_BYTES*4/3)+100)throw new ExtensionError('IMAGE_HANDOFF_LIMIT');
      const match=/^data:(image\/(?:png|jpeg));base64,([A-Za-z0-9+/]+={0,2})$/.exec(item.data);
      if(!match||match[2].length%4||!Number.isSafeInteger(item.width)||!Number.isSafeInteger(item.height)||item.width<1||item.height<1||item.width*item.height>32_000_000)throw new ExtensionError('PAYLOAD_INVALID');
      return {type:'image',title:item.title,sourceUrl:item.sourceUrl,capturedAt:item.capturedAt,data:item.data,width:item.width,height:item.height,bytes:match[2].length*3/4-(match[2].endsWith('==')?2:match[2].endsWith('=')?1:0)};
    }
    if(typeof item.text!=='string'||!item.text.trim()||item.text.length>MAX_CHARACTERS)throw new ExtensionError('PAYLOAD_INVALID');
    return {type:item.type,title:item.title,sourceUrl:item.sourceUrl,capturedAt:item.capturedAt,text:item.text};
  });
  const result = {handoff:value.handoff,protocol:PROTOCOL,route:value.route,requirement:value.requirement,items};
  const imageIssue=imageSelectionIssue(items);if(imageIssue)throw new ExtensionError(imageIssue);
  if (characterUsage(result.requirement, items) > MAX_CHARACTERS) throw new ExtensionError('CHARACTER_LIMIT');
  return result;
}
export function toMarkdown(items) {
  return '# 资料篮（PPT Smith 浏览器插件收集）\n\n' + items.map((item, i) => {
    const date = new Intl.DateTimeFormat('sv-SE', {timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(item.capturedAt));
    const singleLine = value => String(value).replace(/[\r\n\u0000-\u001f]/g,' ');
    const content=item.type==='image'?`图片参考资料：${imageFileName(item,i)}（${item.width} × ${item.height}）。结合其他资料读取图中文字、图表和视觉信息；无法辨认的内容需核实。`:item.text;
    return `## [${i+1}] ${singleLine(item.title)}\n- 来源：${singleLine(item.sourceUrl)}\n- 收集时间：${date}\n\n${content}\n`;
  }).join('\n');
}
export const characterUsage = (requirement = '', items = []) => requirement.length + (items.length ? toMarkdown(items).length : 0);
export const eligibleItems = items => items.filter(item => item.selected && !item.deletedAt);
export const imageFileName=(item,index)=>`pptsmith-source-${String(index+1).padStart(2,'0')}.${(item.data?.startsWith('data:image/jpeg;')||item.blob?.type==='image/jpeg')?'jpg':'png'}`;
export function imageSelectionIssue(items){
  const images=items.filter(item=>item.type==='image');
  if(images.length>MAX_SOURCE_IMAGES||images.reduce((sum,item)=>sum+(item.blob?.size??item.bytes??0),0)>MAX_HANDOFF_IMAGE_BYTES||images.reduce((sum,item)=>sum+item.width*item.height,0)>96_000_000)return 'IMAGE_HANDOFF_LIMIT';
  if(images.some(item=>item.width*item.height>32_000_000))return 'IMAGE_HANDOFF_LIMIT';
  return null;
}
export async function serializeItems(items){
  const issue=imageSelectionIssue(items);if(issue)throw new ExtensionError(issue);
  return Promise.all(items.map(async item=>{
    if(item.type!=='image')return item;
    if(!(item.blob instanceof Blob)||!['image/png','image/jpeg'].includes(item.blob.type))throw new ExtensionError('IMAGE_UNAVAILABLE');
    const bytes=new Uint8Array(await item.blob.arrayBuffer());let binary='';
    for(let offset=0;offset<bytes.length;offset+=32768)binary+=String.fromCharCode(...bytes.subarray(offset,offset+32768));
    return {...item,blob:undefined,data:`data:${item.blob.type};base64,${btoa(binary)}`};
  }));
}
export function safePurchaseUrl(value) {
  if (!value) return null;
  try {const u = new URL(value); return u.protocol === 'https:' && !u.username && !u.password && u.href.length <= 2000 ? u.href : null;} catch {return null;}
}
export function sanitizeStatus(value) {
  if (!value || typeof value.hasCode !== 'boolean') throw new ExtensionError('STATUS_INVALID');
  if (value.balance != null && (!Number.isSafeInteger(value.balance) || value.balance < 0)) throw new ExtensionError('STATUS_INVALID');
  return {balance:value.balance ?? null,hasCode:value.hasCode,purchaseUrl:safePurchaseUrl(value.purchaseUrl),purchaseUrls:{zh:safePurchaseUrl(value.purchaseUrls?.zh),en:safePurchaseUrl(value.purchaseUrls?.en)},syncedAt:new Date().toISOString()};
}
export function trustedSiteSender(sender, origin, nonce) {
  try {const u = new URL(sender?.url || sender?.tab?.url); return sender?.frameId === 0 && u.origin === origin && (nonce === undefined || u.searchParams.get('handoff') === nonce);} catch {return false;}
}
