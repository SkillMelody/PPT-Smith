import {ExportError,cancelled} from './export-package.mjs';

/** Only IDs returned by this download call are inspected or cancelled. */
export function createChromeDownloader({downloads=chrome.downloads,urls=URL}={}){
  return async function downloadPart(blob,filename,{signal}={}){
    if(signal?.aborted)throw cancelled(signal);
    const url=urls.createObjectURL(blob);
    try{
      const id=await downloads.download({url,filename,saveAs:false,conflictAction:'uniquify'});
      if(!Number.isInteger(id)||id<0)throw new ExportError('EXPORT_DOWNLOAD_FAILED');
      return await new Promise((resolve,reject)=>{
        let settled=false;
        const finish=(error)=>{if(settled)return;settled=true;downloads.onChanged.removeListener(changed);signal?.removeEventListener('abort',abort);error?reject(error):resolve({id});};
        const status=item=>{if(item?.state==='complete')finish();else if(item?.state==='interrupted')finish(new ExportError('EXPORT_DOWNLOAD_FAILED',{reason:item.error}));};
        const changed=delta=>{if(delta.id!==id)return;status({state:delta.state?.current,error:delta.error?.current});};
        const abort=()=>{
          const error=cancelled(signal);
          if(error.code==='EXPORT_CONTEXT_CLOSED'){finish(error);return;}
          Promise.resolve().then(()=>downloads.cancel(id)).catch(()=>{}).finally(()=>finish(error));
        };
        downloads.onChanged.addListener(changed);signal?.addEventListener('abort',abort,{once:true});
        if(signal?.aborted){abort();return;}
        // A tiny local download can finish before its ID promise resolves.
        Promise.resolve().then(()=>downloads.search({id})).then(items=>{if(settled)return;if(items[0])status(items[0]);else finish(new ExportError('EXPORT_DOWNLOAD_FAILED',{reason:'DOWNLOAD_NOT_FOUND'}));}).catch(error=>finish(new ExportError('EXPORT_DOWNLOAD_FAILED',{reason:error.message})));
      });
    }catch(error){if(error instanceof ExportError)throw error;throw new ExportError('EXPORT_DOWNLOAD_FAILED',{reason:error.message});}
    finally{urls.revokeObjectURL(url);}
  };
}
