import {createExportPlan,buildExportPart,ExportError,cancelled} from './export-package.mjs';

export function createExportQueue({buildPart=buildExportPart,downloadPart,onChange=()=>{}}){
  let plan=null,cursor=0,controller=null,running=null,closed=false;
  let state={phase:'idle',part:0,total:0,completed:0};
  const active=()=>['preparing','packing','downloading','paused','cancelling'].includes(state.phase);
  const emit=(phase,extra={})=>{state={phase,part:plan?Math.min(cursor+1,plan.parts.length):0,total:plan?.parts.length||0,completed:cursor,...extra};if(!closed)onChange({...state});};
  async function run(work){
    const promise=Promise.resolve().then(work);running=promise;
    try{await promise;}finally{if(running===promise)running=null;}
  }
  async function process(){
    try{
      while(cursor<plan.parts.length){
        if(controller.signal.aborted)throw cancelled(controller.signal);
        emit('packing');let blob=await buildPart(plan,cursor,{signal:controller.signal});
        if(controller.signal.aborted)throw cancelled(controller.signal);
        emit('downloading');await downloadPart(blob,plan.parts[cursor].filename,{signal:controller.signal});blob=null;
        if(controller.signal.aborted)throw cancelled(controller.signal);
        cursor++;
      }
      emit('completed');plan=null;
    }catch(error){
      if(controller.signal.aborted){emit(closed?'closed':'cancelled');plan=null;}
      else emit('paused',{errorCode:error.code||'EXPORT_BUILD_FAILED',sourceTitle:error.sourceTitle});
    }
  }
  return {
    getState:()=>({...state}),
    async start(readSnapshot,options={}){
      if(active()||running||closed)return false;
      cursor=0;controller=new AbortController();emit('preparing');
      // Lock before the first IndexedDB await, so rapid clicks cannot start two jobs.
      await run(async()=>{
        try{
          const snapshot=typeof readSnapshot==='function'?await readSnapshot():readSnapshot;
          if(controller.signal.aborted)throw cancelled(controller.signal);
          plan=createExportPlan(snapshot,options);
          await process();
        }catch(error){
          emit(controller.signal.aborted?(closed?'closed':'cancelled'):'failed',{errorCode:error.code||'EXPORT_BUILD_FAILED',sourceTitle:error.sourceTitle});plan=null;
        }
      });
      return true;
    },
    async retry(){
      if(state.phase!=='paused'||running||closed)return false;
      controller=new AbortController();await run(process);return true;
    },
    cancel(){
      if(!active())return;
      if(state.phase==='paused'){emit('cancelled');plan=null;return;}
      emit('cancelling');controller.abort('EXPORT_CANCELLED');
    },
    close(){closed=true;controller?.abort('EXPORT_CONTEXT_CLOSED');plan=null;},
  };
}
