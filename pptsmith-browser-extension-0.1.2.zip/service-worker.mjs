import {collectArticle,collectImage,collectSelection,startCapture,crop,saveImage} from './collection.mjs';
import {SITE_ORIGIN,PROTOCOL} from './config.mjs';
import {addItem,listItems,getMeta,putMeta,removeMeta,updateItems,reorder,purgeDeleted} from './db.mjs';
import {ExtensionError,validatePayload,serializeItems,eligibleItems,sanitizeStatus,trustedSiteSender,MAX_IMAGE_BYTES,validSourceUrl} from './core.mjs';

let tail=Promise.resolve(),timeout;
const serial=work=>{const result=tail.then(work);tail=result.catch(()=>{});return result;};
const notify=()=>chrome.runtime.sendMessage({type:'basket:changed'}).catch(()=>{});
const errorCode=error=>typeof error.code==='string'?error.code:/Quota|InvalidState|TransactionInactive|UnknownError/.test(error.name)?'LOCAL_STORAGE_FAILED':/Cannot access|permission|cannot be scripted|extensions gallery/i.test(error.message)?'PAGE_RESTRICTED':error.message?.match(/^[A-Z_]+$/)?error.message:'OPERATION_FAILED';
async function fail(error){await putMeta('notice',{kind:'error',code:errorCode(error),at:Date.now()});notify();}
async function activeTab(){const [tab]=await chrome.tabs.query({active:true,currentWindow:true});if(!tab?.id)throw new ExtensionError('PAGE_RESTRICTED');return tab;}
async function checkJob(){
  const job=await getMeta('handoff');
  if(job?.stage==='waiting'&&Date.now()>job.deadline){job.stage='failed';job.errorCode='HANDOFF_TIMEOUT';delete job.payload;await putMeta('handoff',job);notify();}
  return job;
}
async function beginHandoff(){
  const existing=await checkJob();if(existing&&['waiting','uploading'].includes(existing.stage))throw new ExtensionError('HANDOFF_BUSY');
  const form=await getMeta('form')||{},items=eligibleItems(await listItems()),nonce=crypto.randomUUID();
  const payload=validatePayload({handoff:nonce,protocol:PROTOCOL,route:form.route||'template',requirement:form.requirement||'',items:await serializeItems(items)},nonce);
  let job={nonce,stage:'waiting',ids:items.map(i=>i.id),payload,deadline:Date.now()+10000};
  await putMeta('handoff',job);
  try{
    const prefs=await getMeta('preferences');
    const tab=await chrome.tabs.create({url:`${SITE_ORIGIN}/?from=extension&handoff=${nonce}&route=${payload.route}&lang=${prefs?.lang==='en'?'en':'zh'}`});
    job.tabId=tab.id;await putMeta('handoff',job);clearTimeout(timeout);timeout=setTimeout(()=>serial(checkJob),10010);notify();return job;
  }catch(error){job.stage='failed';job.errorCode='HANDOFF_OPEN_FAILED';delete job.payload;await putMeta('handoff',job);throw error;}
}
function isPanel(sender){try{return sender.id===chrome.runtime.id&&new URL(sender.url).origin===new URL(chrome.runtime.getURL('/')).origin&&new URL(sender.url).pathname==='/sidepanel.html';}catch{return false;}}
async function handle(message,sender){
  if(message.type?.startsWith('bridge:')){
    if(!trustedSiteSender(sender,SITE_ORIGIN))throw new ExtensionError('SENDER_INVALID');
    if(message.type==='bridge:status'){await putMeta('status',sanitizeStatus(message.data));notify();return;}
    const job=await checkJob();
    if(!job||job.tabId!==sender.tab.id||job.nonce!==message.handoff||!trustedSiteSender(sender,SITE_ORIGIN,job.nonce))throw new ExtensionError('HANDOFF_INVALID');
    if(message.type==='bridge:ready'&&message.protocol!==PROTOCOL||message.type==='bridge:done'&&message.protocol!=null&&message.protocol!==PROTOCOL){if(['waiting','uploading'].includes(job.stage)){job.stage='failed';job.errorCode='PROTOCOL_MISMATCH';delete job.payload;await putMeta('handoff',job);notify();}throw new ExtensionError('PROTOCOL_MISMATCH');}
    if(message.type==='bridge:ready'){
      if(job.stage==='uploading'&&job.documentId&&sender.documentId!==job.documentId){job.stage='failed';job.errorCode='HANDOFF_CLOSED';await putMeta('handoff',job);notify();throw new ExtensionError('HANDOFF_USED');}
      if(job.stage!=='waiting')throw new ExtensionError('HANDOFF_USED');
      if(job.payload?.items.some(item=>item.type==='image')&&!message.features?.includes('image-sources-v1')){job.stage='failed';job.errorCode='WEBSITE_IMAGE_UNSUPPORTED';delete job.payload;await putMeta('handoff',job);notify();throw new ExtensionError('WEBSITE_IMAGE_UNSUPPORTED');}
      job.stage='uploading';job.documentId=sender.documentId;clearTimeout(timeout);const payload=job.payload;delete job.payload;await putMeta('handoff',job);notify();return {payload};
    }
    if(message.type==='bridge:done'){
      if(job.stage!=='uploading'||typeof message.ok!=='boolean'||job.documentId&&sender.documentId!==job.documentId)throw new ExtensionError('HANDOFF_USED');
      job.stage=message.ok?'success':'failed';job.errorCode=String(message.errorCode||'UPLOAD_FAILED').slice(0,80);job.completedAt=new Date().toISOString();
      if(message.ok)await updateItems(job.ids,{handedOffAt:job.completedAt});
      if(typeof message.status?.hasCode==='boolean')await putMeta('status',sanitizeStatus(message.status));
      await putMeta('handoff',job);notify();return;
    }
    throw new ExtensionError('MESSAGE_INVALID');
  }
  if(['capture:finish','capture:cancel'].includes(message.type)){
    const cap=await getMeta('capture');
    if(sender.id!==chrome.runtime.id||sender.frameId!==0||!cap||cap.tabId!==sender.tab?.id||cap.token!==message.token||Date.now()-cap.at>120000)throw new ExtensionError('CAPTURE_INVALID');
    await removeMeta('capture');
    if(message.type==='capture:cancel')return;
    if(message.type!=='capture:finish'||message.sourceUrl!==cap.sourceUrl||message.viewport?.width!==cap.viewport.width||message.viewport?.height!==cap.viewport.height)throw new ExtensionError('CAPTURE_INVALID');
    const cut=await crop(cap.blob,message.rect,cap.viewport);await saveImage({title:cap.title,sourceUrl:cap.sourceUrl},cut.blob,cut);return;
  }
  if(!isPanel(sender))throw new ExtensionError('SENDER_INVALID');
  if(message.type==='state:get'){await purgeDeleted();const {payload,...job}=await checkJob()||{};const cap=await getMeta('capture');if(cap&&Date.now()-cap.at>120000)await removeMeta('capture');return {form:await getMeta('form')||{},preferences:await getMeta('preferences')||{},status:await getMeta('status')||null,job:job.stage?job:null,notice:await getMeta('notice')||null};}
  if(message.type==='form:set'){const form={requirement:String(message.requirement||'').slice(0,1_000_001),route:message.route==='create'?'create':'template'};await putMeta('form',form);return;}
  if(message.type==='preferences:set'){await putMeta('preferences',{lang:message.lang==='en'?'en':'zh',theme:['day','night','system'].includes(message.theme)?message.theme:'system'});await createMenus();notify();return;}
  if(message.type==='notice:clear'){await removeMeta('notice');return;}
  if(message.type==='job:dismiss'){const job=await getMeta('handoff');if(job&&!['waiting','uploading'].includes(job.stage))await removeMeta('handoff');notify();return;}
  if(message.type==='website:open'){
    const job=await getMeta('handoff'),status=await getMeta('status');
    if(message.kind==='purchase'){const localized=Boolean(status?.purchaseUrls?.zh||status?.purchaseUrls?.en),url=localized?status.purchaseUrls[message.lang==='en'?'en':'zh']:status?.purchaseUrl;if(!url)throw new ExtensionError('PURCHASE_UNAVAILABLE');await chrome.tabs.create({url});return;}
    if(message.kind==='continue'&&job?.tabId){try{await chrome.tabs.update(job.tabId,{active:true});await chrome.windows.update((await chrome.tabs.get(job.tabId)).windowId,{focused:true});return;}catch{}}
    await chrome.tabs.create({url:SITE_ORIGIN+'/'});return;
  }
  const current=await checkJob();if(current&&['waiting','uploading'].includes(current.stage))throw new ExtensionError('HANDOFF_BUSY');
  if(message.type==='collect:page'){await collectArticle((await activeTab()).id);return;}
  if(message.type==='capture:begin'){await startCapture(await activeTab());return;}
  if(message.type==='handoff:begin')return beginHandoff();
  const ids=Array.isArray(message.ids)?message.ids.filter(id=>typeof id==='string').slice(0,1000):[];
  if(message.type==='items:select'){const allowed=new Set((await listItems()).map(i=>i.id));await updateItems(ids.filter(id=>allowed.has(id)),{selected:Boolean(message.selected)});}
  else if(message.type==='items:delete')await updateItems(ids,{deletedAt:Date.now()});
  else if(message.type==='items:undo')await updateItems(ids,{deletedAt:null});
  else if(message.type==='items:reorder'){const all=await listItems();if(ids.length!==all.length||new Set(ids).size!==all.length||!all.every(i=>ids.includes(i.id)))throw new ExtensionError('ORDER_INVALID');await reorder(ids);}
  else throw new ExtensionError('MESSAGE_INVALID');
  if(current?.stage==='success')await removeMeta('handoff');notify();
}
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  if(!message||message.type==='basket:changed')return;
  serial(()=>handle(message,sender)).then(result=>reply({ok:true,...result})).catch(async error=>{if(isPanel(sender))await fail(error);reply({ok:false,errorCode:errorCode(error)});});return true;
});
async function createMenus(){
  const prefs=await getMeta('preferences'),zh=(prefs?.lang||chrome.i18n.getUILanguage().slice(0,2))!=='en';
  await chrome.contextMenus.removeAll();
  chrome.contextMenus.create({id:'pptsmith-text',title:zh?'加入 PPT Smith 资料篮':'Add to PPT Smith basket',contexts:['selection']});
  chrome.contextMenus.create({id:'pptsmith-image',title:zh?'图片加入 PPT Smith 资料篮':'Add image to PPT Smith basket',contexts:['image']});
  chrome.contextMenus.create({id:'pptsmith-capture',title:zh?'截图选区加入资料篮':'Capture area to source basket',contexts:['page','selection','image']});
  chrome.contextMenus.create({id:'pptsmith-recreate',title:zh?'还原为可编辑 PPT · 即将开放':'Recreate as editable PPT · Coming soon',contexts:['image'],enabled:false});
}
chrome.runtime.onInstalled.addListener(()=>{chrome.storage.local.setAccessLevel?.({accessLevel:'TRUSTED_CONTEXTS'});void createMenus();});
chrome.runtime.onStartup.addListener(()=>{void createMenus();});
chrome.action.onClicked.addListener(tab=>{
  void chrome.sidePanel.open({windowId:tab.windowId}).catch(fail);
  void serial(()=>collectArticle(tab.id)).catch(fail);
});
chrome.contextMenus.onClicked.addListener((info,tab)=>{
  const opening=chrome.sidePanel.open({windowId:tab.windowId});
  void serial(async()=>{
    await opening;
    if(!validSourceUrl(info.pageUrl||tab.url))throw new ExtensionError('PAGE_RESTRICTED');
    if(info.menuItemId==='pptsmith-text')await collectSelection(info,tab);
    else if(info.menuItemId==='pptsmith-image')await collectImage(tab,info.srcUrl);
    else if(info.menuItemId==='pptsmith-capture')await startCapture(tab);
  }).catch(fail);
});
chrome.tabs.onRemoved.addListener(tabId=>{void serial(async()=>{const job=await getMeta('handoff');if(job?.tabId===tabId&&['waiting','uploading'].includes(job.stage)){job.stage='failed';job.errorCode='HANDOFF_CLOSED';delete job.payload;await putMeta('handoff',job);notify();}const cap=await getMeta('capture');if(cap?.tabId===tabId)await removeMeta('capture');});});
chrome.tabs.onUpdated.addListener((tabId,change)=>{if(!change.url)return;void serial(async()=>{const job=await getMeta('handoff');if(job?.tabId!==tabId||!['waiting','uploading'].includes(job.stage))return;let changed=true;try{const url=new URL(change.url);changed=url.origin!==SITE_ORIGIN||url.searchParams.get('handoff')!==job.nonce;}catch{}if(changed){job.stage='failed';job.errorCode='HANDOFF_CLOSED';delete job.payload;await putMeta('handoff',job);notify();}});});
