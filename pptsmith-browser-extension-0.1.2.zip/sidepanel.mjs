import {listItems,getItem} from './db.mjs';
import {characterUsage,eligibleItems,MAX_CHARACTERS,imageSelectionIssue} from './core.mjs';
import {messages} from './i18n.mjs';
import {createExportQueue} from './export-queue.mjs';
import {createChromeDownloader} from './export-downloads.mjs';

const $=id=>document.getElementById(id);
const icon=(name,extra='')=>`<svg class="icon ${extra}" aria-hidden="true"><use href="assets/icons.svg#icon-${name}"></use></svg>`;
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let state={items:[],form:{requirement:'',route:'template'},preferences:{},job:null,status:null},lang='zh',toastTimer,formTimer,dragId,detailId,opener;
const images=new Map();
const t=(key,...args)=>typeof messages[lang][key]==='function'?messages[lang][key](...args):messages[lang][key]||key;
const copy=(zh,en)=>lang==='en'?en:zh;
const pending=()=>['waiting','uploading'].includes(state.job?.stage);
const selected=()=>eligibleItems(state.items);
let exportState={phase:'idle',part:0,total:0,completed:0},basketWrites=Promise.resolve();
const preparingExport=()=>exportState.phase==='preparing';
const editingLocked=()=>pending()||preparingExport();
const exportActive=()=>['preparing','packing','downloading','paused','cancelling'].includes(exportState.phase);
const exportQueue=createExportQueue({downloadPart:createChromeDownloader(),onChange:value=>{
  exportState=value;renderSummary();
  if(value.phase==='completed')toast(t('exportSaved',value.total));
}});
const domain=url=>{try{return new URL(url).hostname;}catch{return '';}};
const errors={
  OPERATION_FAILED:['操作未完成，请稍后重试。资料仍保存在本机。','The operation did not finish. Retry shortly. Your sources remain on this device.'],
  NO_ARTICLE:['未识别到正文，请选中文字后右键加入资料篮。','No article text found. Select text and right-click to add it.'],
  PAGE_RESTRICTED:['当前页面无法读取。请切换到普通网页并点击工具栏 PPT Smith 图标授权当前页。','Cannot read this page. Open a regular webpage and click the PPT Smith toolbar icon to grant access.'],
  IMAGE_NEEDS_VISIBLE_CAPTURE:['图片无法完整读取，请将图片完整滚动到可见区域，或使用截图选区收集。','Show the whole image in the viewport, or use area capture.'],
  IMAGE_UNAVAILABLE:['无法读取这张图片，请使用截图选区收集。','Cannot read this image. Try area capture.'],
  IMAGE_TOO_LARGE:['这张图片过大；请用截图收集需要的区域。','This image is too large. Capture the area you need.'],
  IMAGE_HANDOFF_LIMIT:['每次最多带入 4 张图片，图片合计不超过 14 MiB，单张不超过 3200 万像素。请减少勾选图片。','Select up to 4 images, totaling 14 MiB; each image must be at most 32 megapixels.'],
  WEBSITE_IMAGE_UNSUPPORTED:['网站版本暂不支持图片资料，请更新网站配套后重试；资料已保留。','This website cannot receive image sources yet. Update the website and retry; sources are safe.'],
  CHARACTER_LIMIT:['资料超过 1,000,000 字符，请删减后重试。','Sources exceed 1,000,000 characters. Reduce them and retry.'],
  HANDOFF_TIMEOUT:['网站 10 秒内未响应，资料已保留。请确认网站版本和连接后重试。','The website did not respond within 10 seconds. Sources are safe. Check the connection and website version, then retry.'],
  HANDOFF_CLOSED:['网站页面已关闭或重新载入，交接未完成，资料已保留。','Website page closed or reloaded before handoff finished. Your sources are safe.'],
  PROTOCOL_MISMATCH:['网站版本不兼容，请更新插件并刷新网站后再试。','Website version incompatible. Update the extension and refresh the website.'],
  MATERIAL_REVIEW_REQUIRED:['请到网站确认资料读取说明。确认完成前，资料仍保留在篮中。','Review the source-reading notice on the website. Sources remain in your basket.'],
  HANDOFF_BUSY:['正在交接资料，请等待网站结果。','Handoff is in progress. Wait for the website.'],
  LOCAL_STORAGE_FAILED:['本机存储暂时不可用，请检查浏览器存储空间。','Local storage is unavailable. Check browser storage space.'],
  BASKET_FULL:['资料篮最多保留 1,000 条，请清理后再收集。','The basket holds up to 1,000 sources. Remove some first.'],
  CAPTURE_INVALID:['截图选区已失效，请重新框选，框选期间保持页面尺寸不变。','Capture expired or changed size. Select again without resizing the page.'],
  UPLOAD_FAILED:['网站上传或读取未完成，资料已保留。请到网站查看原因或重试。','Upload or reading did not finish. Sources are safe. View the website or retry.']
};
const errorText=code=>{const pair=errors[code]||errors.OPERATION_FAILED;return pair[lang==='en'?1:0];};
function send(type,data={}){
  const request=chrome.runtime.sendMessage({type,...data}).then(result=>{if(!result?.ok){const e=new Error(errorText(result?.errorCode));e.code=result?.errorCode;throw e;}return result;});
  if(type.startsWith('items:'))basketWrites=Promise.allSettled([basketWrites,request]);
  return request;
}
const action=fn=>(...args)=>Promise.resolve(fn(...args)).catch(error=>toast(error.message,null,true));
function toast(text,undo,error=false){clearTimeout(toastTimer);$('toast').hidden=false;$('toast').classList.toggle('error-toast',error);$('toast').innerHTML=`${icon(error?'alert-circle':'check')}<span>${esc(text)}</span>${undo?`<button id="undo">${t('undo')}</button>`:''}`;if(undo)$('undo').onclick=action(async()=>{await undo();$('toast').hidden=true;});toastTimer=setTimeout(()=>$('toast').hidden=true,undo?7000:4500);}
function modal(title,body,actions){$('modal-title').textContent=title;$('modal-body').innerHTML=`<p class="modal-body-text">${esc(body).replace(/\n/g,'<br>')}</p>`;$('modal-actions').replaceChildren();for(const a of actions||[{label:t('understood'),primary:true}]){const b=document.createElement('button');b.textContent=a.label;b.className=a.primary?'primary':'';b.onclick=action(async()=>{$('modal').close();await a.run?.();});$('modal-actions').append(b);}$('modal').showModal();}
function applyTheme(){const theme=state.preferences.theme||'system';document.documentElement.dataset.appearance=theme==='system'?(matchMedia('(prefers-color-scheme:dark)').matches?'night':'day'):theme;}
async function saveForm(){clearTimeout(formTimer);state.form={requirement:$('requirement').value,route:document.querySelector('input[name=route]:checked').value};await send('form:set',state.form);}
async function dismissSuccess(){if(state.job?.stage==='success'){await send('job:dismiss');state.job=null;renderNotice();}}
async function refresh(){
  const [snapshot,items]=await Promise.all([send('state:get'),listItems()]);
  state={...state,...snapshot,items};
  lang=state.preferences.lang||(chrome.i18n.getUILanguage().toLowerCase().startsWith('zh')?'zh':'en');
  if(document.activeElement!==$('requirement'))$('requirement').value=state.form.requirement||'';
  document.querySelectorAll('input[name=route]').forEach(el=>el.checked=el.value===(state.form.route||'template'));
  render();
  if(state.notice?.at&&Date.now()-state.notice.at<7000){
    const n=state.notice;await send('notice:clear');
    toast(n.code==='COLLECTED'?t('saved'):n.code==='IMAGE_SAVED'?t('imageSaved'):errorText(n.code),null,n.kind==='error');
  }
}
function render(){
  applyTheme();document.documentElement.lang=lang==='zh'?'zh-CN':'en';
  $('basket-title').firstChild.textContent=t('basket')+' ';$('total-count').textContent=state.items.length;
  $('local-label').innerHTML=icon('lock')+t('local');$('collect-page').innerHTML=icon('plus')+t('collect');
  $('capture').innerHTML=icon('scan');$('capture').title=t('capture');$('capture').setAttribute('aria-label',t('capture'));
  $('language').textContent=lang==='zh'?'EN':'中';$('language').setAttribute('aria-label',lang==='zh'?'Switch to English':'切换为中文');
  $('settings').innerHTML=icon('dots');$('settings').setAttribute('aria-label',t('settings'));
  $('close-panel').innerHTML=icon('x');$('close-panel').hidden=!chrome.sidePanel.close;
  $('requirement-label').textContent=t('requirement');$('optional-label').textContent=t('optional');$('requirement').placeholder=t('placeholder');
  $('route-label').textContent=t('route');$('template-label').textContent=t('template');$('create-label').textContent=t('create');$('template-icon').innerHTML=icon('template');$('create-icon').innerHTML=icon('file-text');
  $('privacy-note').innerHTML=icon('lock')+t('privacy');$('modal-close').innerHTML=icon('x');
  renderAccount();renderItems();renderSummary();renderNotice();
}
function renderAccount(){
  const s=state.status,unknown=s?.balance==null,localized=Boolean(s?.purchaseUrls?.zh||s?.purchaseUrls?.en),purchaseUrl=localized?s.purchaseUrls[lang]:s?.purchaseUrl;
  const timestamp=s?.syncedAt?new Intl.DateTimeFormat(lang==='en'?'en-GB':'zh-CN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(s.syncedAt)):'';
  const hint=s?.hasCode===false?t('noCode'):copy('打开网站后同步','Sync after opening the website');
  $('account-bar').innerHTML=`<div><div class="balance-value">${icon('coin')}${unknown?`<span>${t('unknown')}</span>`:`<strong>${s.balance}</strong><span>${t('unit')}</span>`}</div><span class="balance-time">${esc(unknown?hint:copy(`${timestamp} 同步`,`Synced ${timestamp}`))}</span></div><div class="account-links">${purchaseUrl?`<button id="purchase" class="quiet-link purchase-link">${t('purchase')}${icon('arrow-up-right')}</button>`:unknown?`<button id="sync" class="quiet-link purchase-link">${t('sync')}${icon('arrow-up-right')}</button>`:''}<button id="drafts" class="quiet-link">${t('drafts')}${icon('arrow-up-right')}</button></div>`;
  if($('purchase'))$('purchase').onclick=action(()=>send('website:open',{kind:'purchase',lang}));
  if($('sync'))$('sync').onclick=action(()=>send('website:open',{kind:'drafts'}));
  $('drafts').onclick=action(()=>send('website:open',{kind:'drafts'}));
}
function renderSummary(){
  const n=selected().length,form={requirement:$('requirement').value,route:document.querySelector('input[name=route]:checked').value};
  const total=characterUsage(form.requirement,selected());
  $('selection-label').textContent=t('selected',n);$('clear-selected').textContent=t('clear');$('clear-selected').disabled=editingLocked()||n===0;
  $('select-all').checked=n>0&&n===state.items.length;
  $('select-all').indeterminate=n>0&&n<state.items.length;
  $('select-all').disabled=editingLocked()||!state.items.length;$('select-all').setAttribute('aria-label',t('selectAll'));
  $('usage-description').textContent=t('usage',n);$('usage-number').textContent=`${total.toLocaleString()} / 1,000,000`;
  $('usage-fill').style.width=`${Math.min(100,total/10000)}%`;$('usage-fill').parentElement.classList.toggle('over',total>MAX_CHARACTERS);
  $('usage-fill').parentElement.setAttribute('aria-valuenow',Math.min(total,MAX_CHARACTERS));
  const imageIssue=imageSelectionIssue(selected());
  const invalid=n===0||total>MAX_CHARACTERS||Boolean(imageIssue);
  $('footer-error').hidden=!invalid;
  $('footer-error').textContent=imageIssue?t('generationImageLimit'):total>MAX_CHARACTERS?t('generationCharacterLimit',total-MAX_CHARACTERS):t('noSelection');
  $('generate').disabled=pending()||invalid||preparingExport();
  $('generate').innerHTML=`${pending()?icon('loader-2','spin'):''}<span>${t(pending()?'handoff':state.job?.stage==='success'?'continue':'generate')}</span>${pending()?'':icon('arrow-up-right')}`;
  $('route-hint').textContent=t(form.route==='template'?'templateHint':'createHint');
  $('collect-page').disabled=editingLocked();$('capture').disabled=editingLocked();$('requirement').disabled=pending();document.querySelectorAll('input[name=route]').forEach(el=>el.disabled=pending());
  document.querySelectorAll('#basket-items input,#basket-items .delete-item,#basket-items .drag-handle').forEach(el=>el.disabled=editingLocked());
  renderExport();
}
function exportErrorText(value){
  const key=({EXPORT_EMPTY:'noSelection',EXPORT_IMAGE_MISSING:'exportImageMissing',EXPORT_SOURCE_INVALID:'exportSourceInvalid',EXPORT_SOURCE_MISSING:'exportSourceInvalid',EXPORT_SOURCE_TOO_LARGE:'exportSourceTooLarge',EXPORT_DOWNLOAD_FAILED:'exportDownloadFailed'})[value.errorCode]||'exportBuildFailed';
  return `${value.sourceTitle?`“${value.sourceTitle}” — `:''}${t(key)}`;
}
function renderExport(){
  const busy=['preparing','packing','downloading','cancelling'].includes(exportState.phase),button=$('export-sources');
  button.disabled=exportActive()||selected().length===0;button.textContent=t(busy?'exporting':'exportSources');button.setAttribute('aria-busy',String(busy));
  const box=$('export-status');box.replaceChildren();box.hidden=exportState.phase==='idle';if(box.hidden)return;
  const label=document.createElement('span');
  const text=exportState.phase==='preparing'?t('exportPreparing'):exportState.phase==='packing'?t('exportPacking',exportState.part,exportState.total):exportState.phase==='downloading'?t('exportDownloading',exportState.part,exportState.total):exportState.phase==='paused'?`${t('exportPaused',exportState.part,exportState.total)} ${exportErrorText(exportState)}`:exportState.phase==='failed'?exportErrorText(exportState):exportState.phase==='cancelling'?t('exportCancelling'):exportState.phase==='completed'?t('exportSaved',exportState.total):t('exportStopped',exportState.completed);
  label.textContent=text;box.append(label);box.classList.toggle('is-error',['failed','paused'].includes(exportState.phase));box.setAttribute('role',['failed','paused'].includes(exportState.phase)?'alert':'status');
  const controls=document.createElement('div');controls.className='export-status-actions';
  if(exportState.phase==='paused'){const retry=document.createElement('button');retry.id='export-retry';retry.type='button';retry.textContent=t('exportRetry');retry.onclick=action(()=>exportQueue.retry());controls.append(retry);}
  if(exportActive()){const end=document.createElement('button');end.id='export-cancel';end.type='button';end.textContent=t('exportStop');end.disabled=exportState.phase==='cancelling';end.onclick=()=>exportQueue.cancel();controls.append(end);}
  if(controls.childElementCount)box.append(controls);
}
async function startExport(){
  const ids=new Set([...document.querySelectorAll('#basket-items .clip-card')].filter(card=>card.querySelector('input')?.checked).map(card=>card.dataset.id));
  const titles=new Map(state.items.map(item=>[item.id,item.title]));
  await exportQueue.start(async()=>{
    await basketWrites;const items=await listItems(),present=new Set(items.map(item=>item.id));
    const missing=[...ids].find(id=>!present.has(id));if(missing)throw Object.assign(new Error('EXPORT_SOURCE_MISSING'),{code:'EXPORT_SOURCE_MISSING',sourceTitle:titles.get(missing)});
    return items.map(item=>({...item,selected:ids.has(item.id)}));
  },{notes:$('requirement').value,lang});
}
function renderItems(){
  const scroll=$('basket-scroll').scrollTop;
  const oldFocus=document.activeElement?.closest('[data-id]');const focusId=oldFocus?.dataset.id,focusClass=document.activeElement?.className;
  for(const [id,url] of images)if(!state.items.some(i=>i.id===id)){URL.revokeObjectURL(url);images.delete(id);}
  const root=$('basket-items');root.replaceChildren();
  if(!state.items.length){root.innerHTML=`<div class="empty-basket"><div class="empty-symbol">${icon('basket')}</div><h3>${t('emptyTitle')}</h3><p>${t('emptyBody')}</p><div class="empty-methods"><span>${icon('file-text')}${t('wholePage')}</span><span>${icon('mouse')}${t('rightClick')}</span><span>${icon('scan')}${t('screenshot')}</span></div><p class="trial-note"><strong>${t('trial')}</strong><br>${t('trialDetail')}</p></div>`;return;}
  for(const item of state.items){
    const image=item.type==='image';if(image&&item.blob instanceof Blob&&!images.has(item.id))images.set(item.id,URL.createObjectURL(item.blob));
    const el=document.createElement('article');el.className=`clip-card ${item.selected?'is-selected':''} ${image?'image-card':''}`;el.dataset.id=item.id;el.setAttribute('role','listitem');
    el.innerHTML=`<input type="checkbox" ${item.selected?'checked':''} ${pending()?'disabled':''} aria-label="${esc(copy('选择 ','Select ')+item.title)}"><div class="clip-content"><button class="clip-open" aria-label="${esc(t('detail')+': '+item.title)}">${image?`<div class="image-row">${images.has(item.id)?`<img class="image-thumb" src="${images.get(item.id)}" alt="">`:`<span class="missing-image" aria-label="${t('exportImageMissing')}">${icon('photo')}</span>`}<div><div class="clip-title">${esc(item.title)}</div><span class="image-tag">${t('onlyLocal')}</span></div></div>`:`<div class="clip-title">${esc(item.title)}</div><p class="clip-excerpt">${esc(item.text.slice(0,120))}</p>`}</button><div class="clip-meta">${icon(image?'photo':item.type==='article'?'file-text':'typography')}<span class="clip-domain">${esc(domain(item.sourceUrl))}</span><span class="meta-dot">·</span><span>${image?`${item.width} × ${item.height}`:t('chars',item.text.length)}</span></div>${item.handedOffAt?`<div class="handed-label">${icon('check')}${t('handed')}</div>`:''}</div><div class="clip-actions"><button class="drag-handle" draggable="${!pending()}" aria-label="${t('drag')}" title="${t('drag')}" ${pending()?'disabled':''}>${icon('grip-vertical')}</button><button class="delete-item" aria-label="${esc(t('remove')+': '+item.title)}" title="${t('remove')}" ${pending()?'disabled':''}>${icon('x')}</button></div>`;
    el.querySelector('input').onchange=action(e=>send('items:select',{ids:[item.id],selected:e.target.checked}));
    el.querySelector('.clip-open').onclick=action(()=>showDetail(item.id));el.querySelector('.delete-item').onclick=action(()=>remove([item.id]));
    const handle=el.querySelector('.drag-handle');handle.onclick=()=>sortItem(item.id);
    handle.ondragstart=e=>{dragId=item.id;e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',item.id);el.classList.add('is-dragged');};
    handle.ondragend=()=>{dragId=null;document.querySelectorAll('.is-dragged,.drop-target').forEach(n=>n.classList.remove('is-dragged','drop-target'));};
    el.ondragover=e=>{if(dragId&&!pending()){e.preventDefault();el.classList.add('drop-target');}};el.ondragleave=()=>el.classList.remove('drop-target');
    el.ondrop=action(async e=>{e.preventDefault();if(!dragId||pending())return;const ids=state.items.map(i=>i.id),from=ids.indexOf(dragId),to=ids.indexOf(item.id);if(from<0||to<0)return;ids.splice(to,0,...ids.splice(from,1));dragId=null;await send('items:reorder',{ids});});
    root.append(el);
  }
  $('basket-scroll').scrollTop=scroll;
  if(focusId&&typeof focusClass==='string'){const card=[...root.children].find(e=>e.dataset.id===focusId);const target=card?.querySelector(focusClass.includes('drag-handle')?'.drag-handle':focusClass.includes('clip-open')?'.clip-open':'input');target?.focus({preventScroll:true});}
}
function renderNotice(){
  const job=state.job,el=$('notice');el.hidden=!job;if(!job)return;
  const success=job.stage==='success',waiting=['waiting','uploading'].includes(job.stage);
  el.className='panel-notice '+(success?'success':waiting?'':'error');el.setAttribute('role',waiting||success?'status':'alert');
  const title=success?t('successTitle',job.ids.length):waiting?t('pendingTitle'):copy('资料交接未完成','Source handoff incomplete');
  const body=success?t(state.form.route==='create'?'successCreate':'successBody'):waiting?(job.stage==='uploading'?copy('网站正在上传和读取资料，请保留网站标签页。','The website is uploading and reading your sources. Keep its tab open.'):t('pendingBody')):errorText(job.errorCode);
  el.innerHTML=`<div class="notice-row">${icon(success?'check':waiting?'loader-2':'alert-circle',waiting?'spin':'')}<div class="notice-copy"><strong>${esc(title)}</strong><p>${esc(body)}</p><div class="notice-actions">${success?`<button id="keep">${t('keep')}</button><button id="clean">${t('clean')}</button>`:waiting?'':`<button id="retry">${t('retry')}</button><button id="view-website">${t('viewWebsite')}</button>`}</div></div></div>`;
  if($('keep'))$('keep').onclick=action(()=>send('job:dismiss'));
  if($('clean'))$('clean').onclick=()=>{const ids=job.ids.filter(id=>state.items.some(i=>i.id===id));modal(t('cleanTitle'),t('cleanBody',ids.length),[{label:t('cancel')},{label:t('confirmClean'),primary:true,run:()=>remove(ids)}]);};
  if($('retry'))$('retry').onclick=action(startHandoff);
  if($('view-website'))$('view-website').onclick=action(()=>send('website:open',{kind:'continue'}));
}
async function remove(ids){await send('items:delete',{ids});toast(t('deleted',ids.length),()=>send('items:undo',{ids}));}
function sortItem(id){const idx=state.items.findIndex(i=>i.id===id);modal(t('sortTitle'),t('sortBody'),[{label:t('cancel')},...(idx>0?[{label:t('prev'),run:()=>move(-1)}]:[]),...(idx<state.items.length-1?[{label:t('next'),primary:true,run:()=>move(1)}]:[])]);async function move(delta){const ids=state.items.map(i=>i.id);ids.splice(idx+delta,0,...ids.splice(idx,1));await send('items:reorder',{ids});}}
async function showDetail(id){
  const item=await getItem(id);if(!item||item.deletedAt)return;detailId=id;opener=document.activeElement;
  $('detail-layer').hidden=false;Array.from($('plugin-panel').children).forEach(el=>{if(el.id!=='detail-layer')el.inert=true;});
  $('detail-layer').innerHTML=`<header class="detail-header"><button id="detail-back" class="icon-button" aria-label="${t('previewBack')}">${icon('arrow-left')}</button>${t('detail')}</header><div class="detail-body"><div class="detail-kind">${icon(item.type==='image'?'photo':item.type==='text'?'typography':'file-text')}${t(item.type)}</div><h3>${esc(item.title)}</h3><a class="detail-source" href="${esc(item.sourceUrl)}" target="_blank" rel="noopener noreferrer">${esc(item.sourceUrl)}${icon('arrow-up-right')}</a><p class="detail-time">${esc(new Date(item.capturedAt).toLocaleString(lang==='zh'?'zh-CN':'en-GB'))}</p>${item.type==='image'?`<div class="detail-image"><img src="${images.get(id)}" alt="${esc(item.title)}"></div><p class="detail-text">${t('imageDetail')}</p>`:`<p class="detail-text">${esc(item.text)}</p>`}</div><footer class="detail-footer"><span>${item.type==='image'?`${item.width} × ${item.height}`:t('chars',item.text.length)}</span><button id="detail-remove" ${pending()?'disabled':''}>${icon('trash')}${t('remove')}</button></footer>`;
  $('detail-back').onclick=closeDetail;$('detail-remove').onclick=action(async()=>{await remove([id]);closeDetail();});$('detail-back').focus();
}
function closeDetail(){$('detail-layer').hidden=true;detailId=null;Array.from($('plugin-panel').children).forEach(el=>el.inert=false);if(opener?.isConnected)opener.focus();else $('collect-page').focus();}
async function startHandoff(){$('generate').disabled=true;try{await saveForm();await send('handoff:begin');await refresh();}finally{renderSummary();}}
function settings(){const pop=$('settings-popover');pop.hidden=!pop.hidden;if(pop.hidden)return;pop.innerHTML=`<button id="theme-setting"><span>${t('appearance')}</span>${icon('sun')}</button><button id="help-setting"><span>${t('help')}</span>${icon('info-circle')}</button><button id="privacy-setting"><span>${t('privacyTitle')}</span>${icon('lock')}</button><p class="settings-note">${t('settingsNote')}</p>`;
  $('theme-setting').onclick=action(async()=>{await send('preferences:set',{lang,theme:document.documentElement.dataset.appearance==='night'?'day':'night'});pop.hidden=true;});
  $('help-setting').onclick=()=>{pop.hidden=true;modal(t('help'),t('helpBody'));};
  $('privacy-setting').onclick=()=>{pop.hidden=true;modal(t('privacyTitle'),copy('资料篮保存在当前浏览器本机，不跨设备同步。导出资料包在本机完成，不上传、不消耗点数；下载权限只用于发起和跟踪本插件资料包。点击带入时，发送所选文字与图片、标题、来源、收集时间和制作需求。网站在你继续制作时将资料交给配置的模型读取。插件不保存兑换码、不读取浏览记录。卸载扩展会删除扩展本地资料。','Sources stay in this browser on this device, with no device sync. Export packages are created locally with no upload or points used. Download access only starts and tracks this extension’s packages. Handoff sends selected text and images, titles, URLs, collection times and your request. The configured models read these sources when you continue production. The extension stores no redemption codes and reads no browsing history. Uninstalling removes its local data.'));};}
let refreshing=false,dirty=false;
async function scheduleRefresh(){if(refreshing){dirty=true;return;}refreshing=true;try{do{dirty=false;await refresh();}while(dirty);}catch(e){toast(errorText(e.code||'LOCAL_STORAGE_FAILED'),null,true);}finally{refreshing=false;}}
chrome.runtime.onMessage.addListener(message=>{if(message?.type==='basket:changed')void scheduleRefresh();});
$('collect-page').onclick=action(async()=>{const b=$('collect-page');b.disabled=true;b.innerHTML=icon('loader-2','spin')+t('collecting');try{await send('collect:page');}finally{await scheduleRefresh();}});
$('capture').onclick=action(()=>send('capture:begin'));
$('select-all').onchange=action(e=>send('items:select',{ids:state.items.map(i=>i.id),selected:e.target.checked}));
$('clear-selected').onclick=()=>{const ids=selected().map(i=>i.id);modal(t('clearTitle'),t('clearBody',ids.length),[{label:t('cancel')},{label:t('confirmDelete'),primary:true,run:()=>remove(ids)}]);};
$('language').onclick=action(()=>send('preferences:set',{lang:lang==='zh'?'en':'zh',theme:state.preferences.theme||'system'}));
$('settings').onclick=settings;$('modal-close').onclick=()=>$('modal').close();
$('close-panel').onclick=action(async()=>{const w=await chrome.windows.getCurrent();await chrome.sidePanel.close({windowId:w.id});});
$('requirement').oninput=()=>{renderSummary();clearTimeout(formTimer);formTimer=setTimeout(action(async()=>{await saveForm();await dismissSuccess();}),200);};
document.querySelectorAll('input[name=route]').forEach(el=>el.onchange=action(async()=>{await saveForm();await dismissSuccess();renderSummary();}));
$('generate').onclick=action(()=>state.job?.stage==='success'?send('website:open',{kind:'continue'}):startHandoff());
$('export-sources').onclick=action(startExport);
document.addEventListener('click',e=>{if(!e.target.closest('#settings-popover')&&!e.target.closest('#settings'))$('settings-popover').hidden=true;});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){if(detailId)closeDetail();$('settings-popover').hidden=true;}});
matchMedia('(prefers-color-scheme:dark)').addEventListener('change',applyTheme);
window.addEventListener('pagehide',()=>{exportQueue.close();for(const url of images.values())URL.revokeObjectURL(url);});
await scheduleRefresh();
