import {addItem,getMeta,putMeta} from './db.mjs';
import {ExtensionError,MAX_IMAGE_BYTES,validSourceUrl} from './core.mjs';
const notify=()=>chrome.runtime.sendMessage({type:'basket:changed'}).catch(()=>{});
async function collector(tabId){await chrome.scripting.executeScript({target:{tabId},files:['vendor/Readability.js','content/collect.js']});}
async function collectArticle(tabId){
  const job=await getMeta('handoff');if(job&&['waiting','uploading'].includes(job.stage))throw new ExtensionError('HANDOFF_BUSY');
  await collector(tabId);const result=await chrome.tabs.sendMessage(tabId,{type:'collect:article'});
  if(!result?.ok)throw new ExtensionError(result?.errorCode||'NO_ARTICLE');
  await addItem({...result.item,id:crypto.randomUUID(),selected:true,handedOffAt:null});await putMeta('notice',{kind:'success',code:'COLLECTED',at:Date.now()});notify();
}
async function dataBlob(dataUrl){const result=await fetch(dataUrl);const blob=await result.blob();if(blob.size>MAX_IMAGE_BYTES)throw new ExtensionError('IMAGE_TOO_LARGE');return blob;}
async function crop(blob,rect,viewport){
  if(!rect||!viewport||![rect.x,rect.y,rect.width,rect.height,viewport.width,viewport.height].every(Number.isFinite)||rect.x<0||rect.y<0||rect.width<1||rect.height<1||viewport.width<1||viewport.height<1||rect.x+rect.width>viewport.width+1||rect.y+rect.height>viewport.height+1)throw new ExtensionError('CAPTURE_INVALID');
  const bitmap=await createImageBitmap(blob),sx=bitmap.width/viewport.width,sy=bitmap.height/viewport.height;
  const width=Math.max(1,Math.round(rect.width*sx)),height=Math.max(1,Math.round(rect.height*sy));
  if(width*height>40_000_000){bitmap.close();throw new ExtensionError('IMAGE_TOO_LARGE');}
  const canvas=new OffscreenCanvas(width,height);canvas.getContext('2d').drawImage(bitmap,rect.x*sx,rect.y*sy,rect.width*sx,rect.height*sy,0,0,width,height);bitmap.close();
  return {blob:await canvas.convertToBlob({type:'image/png'}),width,height};
}
async function saveImage(item,blob,size){
  if(blob.size>MAX_IMAGE_BYTES||!['image/png','image/jpeg'].includes(blob.type))throw new ExtensionError('IMAGE_TOO_LARGE');
  let dimensions=size;
  if(!dimensions){const image=await createImageBitmap(blob);dimensions={width:image.width,height:image.height};image.close();}
  await addItem({...item,...dimensions,blob,id:crypto.randomUUID(),type:'image',selected:true,handedOffAt:null,capturedAt:new Date().toISOString()});
  await putMeta('notice',{kind:'success',code:'IMAGE_SAVED',at:Date.now()});notify();
}
async function collectImage(tab,srcUrl){
  await collector(tab.id);const r=await chrome.tabs.sendMessage(tab.id,{type:'collect:image',srcUrl});if(!r?.ok)throw new ExtensionError(r?.errorCode||'IMAGE_UNAVAILABLE');
  if(r.dataUrl)return saveImage(r.item,await dataBlob(r.dataUrl));
  const screenshot=await dataBlob(await chrome.tabs.captureVisibleTab(tab.windowId,{format:'png'}));
  const cut=await crop(screenshot,r.rect,r.viewport);await saveImage(r.item,cut.blob,cut);
}
async function collectSelection(info,tab){
  if(!validSourceUrl(info.pageUrl||tab.url))throw new ExtensionError('PAGE_RESTRICTED');
  if(!info.selectionText?.trim())throw new ExtensionError('NO_SELECTION');
  if(info.selectionText.length>1_000_000)throw new ExtensionError('CHARACTER_LIMIT');
  await addItem({id:crypto.randomUUID(),type:'text',title:(tab.title||info.selectionText).slice(0,1000),sourceUrl:info.pageUrl||tab.url,text:info.selectionText,capturedAt:new Date().toISOString(),selected:true,handedOffAt:null});
  await putMeta('notice',{kind:'success',code:'COLLECTED',at:Date.now()});notify();
}
async function startCapture(tab){
  const source=await chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>({sourceUrl:location.href,title:document.title.slice(0,1000),viewport:{width:innerWidth,height:innerHeight}})});
  const blob=await dataBlob(await chrome.tabs.captureVisibleTab(tab.windowId,{format:'png'}));
  const token=crypto.randomUUID();await putMeta('capture',{token,tabId:tab.id,blob,...source[0].result,at:Date.now()});
  await chrome.scripting.executeScript({target:{tabId:tab.id},files:['content/capture.js']});
  const prefs=await getMeta('preferences');await chrome.tabs.sendMessage(tab.id,{type:'capture:start',token,lang:prefs?.lang||chrome.i18n.getUILanguage().slice(0,2)});
}

export {collectArticle,collectImage,collectSelection,startCapture,crop,saveImage};
