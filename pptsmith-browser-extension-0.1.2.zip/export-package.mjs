export const EXPORT_PART_BYTES=256*1024*1024;
const encoder=new TextEncoder();
const byteLength=value=>encoder.encode(value).byteLength;
const pad=(number,width=4)=>String(number).padStart(width,'0');
const line=value=>String(value).replace(/[\u0000-\u001f]/g,' ');
const markdownLabel=value=>line(value).replace(/[\\`*_[\]<>]/g,'\\$&');

export class ExportError extends Error{
  constructor(code,{sourceTitle,reason}={}){super(code);this.code=code;this.sourceTitle=sourceTitle;this.reason=reason;}
}
export const cancelled=signal=>new ExportError(signal?.reason==='EXPORT_CONTEXT_CLOSED'?'EXPORT_CONTEXT_CLOSED':'EXPORT_CANCELLED');
const check=signal=>{if(signal?.aborted)throw cancelled(signal);};

function snapshotSource(item,index){
  const source={order:index+1,type:item.type,title:item.title,sourceUrl:item.sourceUrl,capturedAt:item.capturedAt};
  if(!['article','text','image'].includes(item.type)||!['title','sourceUrl','capturedAt'].every(key=>typeof source[key]==='string'))throw new ExportError('EXPORT_SOURCE_INVALID',{sourceTitle:item.title});
  if(item.type==='image'){
    if(!(item.blob instanceof Blob)||!item.blob.size||!['image/png','image/jpeg'].includes(item.blob.type))throw new ExportError('EXPORT_IMAGE_MISSING',{sourceTitle:item.title});
    Object.assign(source,{imagePath:`images/${pad(index+1)}.${item.blob.type==='image/jpeg'?'jpg':'png'}`,width:item.width,height:item.height});
    return {source:Object.freeze(source),blob:item.blob};
  }
  if(typeof item.text!=='string')throw new ExportError('EXPORT_SOURCE_INVALID',{sourceTitle:item.title});
  source.text=item.text;
  return {source:Object.freeze(source)};
}
function section(source,lang){
  const zh=lang!=='en',kind=({article:zh?'整页正文':'Full article',text:zh?'文字摘录':'Text excerpt',image:zh?'图片 / 截图':'Image / capture'})[source.type];
  const url=line(source.sourceUrl).replace(/</g,'%3C').replace(/>/g,'%3E');
  return `## ${pad(source.order)}. ${markdownLabel(source.title)}\n\n- ${zh?'类型':'Type'}: ${kind}\n- ${zh?'来源':'Source'}: <${url}>\n- ${zh?'收集时间':'Collected'}: ${line(source.capturedAt)}\n\n${source.type==='image'?`![${markdownLabel(source.title)}](${source.imagePath})\n\n${source.width} × ${source.height}`:source.text}\n\n`;
}
function manifest(plan,index,count,sources){
  return {formatVersion:1,exportId:plan.exportId,exportedAt:plan.exportedAt,part:{index,count},totalSources:plan.totalSources,...(plan.notes.trim()?{notes:plan.notes}:{}),sources};
}
function header(plan,index,count){
  const zh=plan.lang!=='en';
  return `# ${zh?'资料包':'Source bundle'} · PPT Smith\n\n- ${zh?'导出时间':'Exported'}: ${plan.exportedAt}\n- ${zh?'分包':'Part'}: ${index} / ${count}\n- ${zh?'本次所选资料':'Selected sources'}: ${plan.totalSources}\n\n${plan.notes.trim()?`## ${zh?'补充说明':'Additional notes'}\n\n${plan.notes}\n\n`:''}`;
}
function fileStamp(date){return `${date.getFullYear()}${pad(date.getMonth()+1,2)}${pad(date.getDate(),2)}-${pad(date.getHours(),2)}${pad(date.getMinutes(),2)}${pad(date.getSeconds(),2)}`;}

/** Snapshot only collected data; website validation and handoff state do not participate. */
export function createExportPlan(items,{notes='',lang='zh',exportedAt=new Date(),exportId=crypto.randomUUID(),maxPartBytes=EXPORT_PART_BYTES}={}){
  const date=new Date(exportedAt);
  if(!Number.isFinite(date.getTime())||typeof notes!=='string'||!Number.isSafeInteger(maxPartBytes)||maxPartBytes<1)throw new ExportError('EXPORT_SOURCE_INVALID');
  const selected=items.filter(item=>item.selected&&!item.deletedAt).slice().sort((a,b)=>(a.order??0)-(b.order??0)||String(a.capturedAt).localeCompare(String(b.capturedAt)));
  if(!selected.length)throw new ExportError('EXPORT_EMPTY');
  const records=selected.map(snapshotSource);
  const plan={formatVersion:1,exportId,exportedAt:date.toISOString(),notes,lang:lang==='en'?'en':'zh',totalSources:records.length,maxPartBytes,prefix:`pptsmith-materials-${fileStamp(date)}`};
  // Reserve the longest possible part numbering. UTF-8 JSON, Markdown and image
  // bytes all count; a source and its image can never straddle two archives.
  const overhead=byteLength(header(plan,records.length,records.length))+byteLength(JSON.stringify(manifest(plan,records.length,records.length,[])));
  let current=[],used=overhead;const groups=[];
  for(const record of records){
    const weight=byteLength(section(record.source,plan.lang))+byteLength(JSON.stringify(record.source))+(record.blob?.size||0);
    if(overhead+weight>maxPartBytes)throw new ExportError('EXPORT_SOURCE_TOO_LARGE',{sourceTitle:record.source.title});
    if(current.length&&used+weight+1>maxPartBytes){groups.push(current);current=[];used=overhead;}
    used+=weight+(current.length?1:0);current.push(Object.freeze(record));
  }
  if(current.length)groups.push(current);
  const digits=Math.max(3,String(groups.length).length);
  plan.parts=groups.map((entries,index)=>{
    const multi=groups.length>1,suffix=`part-${pad(index+1,digits)}-of-${pad(groups.length,digits)}`;
    return Object.freeze({index:index+1,root:multi?`part-${pad(index+1,digits)}/`:'',filename:`${plan.prefix}${multi?'-'+suffix:''}.zip`,entries:Object.freeze(entries)});
  });
  return Object.freeze({...plan,parts:Object.freeze(plan.parts)});
}

export function partDocuments(plan,partIndex){
  const part=plan.parts[partIndex];if(!part)throw new ExportError('EXPORT_SOURCE_INVALID');
  const sources=part.entries.map(entry=>entry.source);
  return {markdown:header(plan,part.index,plan.parts.length)+sources.map(source=>section(source,plan.lang)).join(''),json:JSON.stringify(manifest(plan,part.index,plan.parts.length,sources))};
}

export async function buildExportPart(plan,partIndex,{JSZip=globalThis.JSZip,signal,onProgress=()=>{}}={}){
  check(signal);
  if(typeof JSZip!=='function')throw new ExportError('EXPORT_BUILD_FAILED');
  const part=plan.parts[partIndex],documents=partDocuments(plan,partIndex),zip=new JSZip(),date=new Date(plan.exportedAt);
  zip.file(part.root+'materials.md',documents.markdown,{date,compression:'DEFLATE',compressionOptions:{level:6}});
  zip.file(part.root+'sources.json',documents.json,{date,compression:'DEFLATE',compressionOptions:{level:6}});
  for(const entry of part.entries){
    check(signal);if(!entry.blob)continue;
    let bytes;try{bytes=new Uint8Array(await entry.blob.arrayBuffer());}catch{throw new ExportError('EXPORT_IMAGE_MISSING',{sourceTitle:entry.source.title});}
    check(signal);zip.file(part.root+entry.source.imagePath,bytes,{date,compression:'STORE'});
  }
  // Cancellation stops the next download; JSZip's current asynchronous build is
  // allowed to settle before another export starts, keeping memory bounded.
  const bytes=await zip.generateAsync({type:'uint8array',streamFiles:true},value=>{if(!signal?.aborted)onProgress(value.percent);});
  check(signal);return new Blob([bytes],{type:'application/zip'});
}
