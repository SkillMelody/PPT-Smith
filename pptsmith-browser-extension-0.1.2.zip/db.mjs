const NAME = 'pptsmith-source-basket';
let opening;
export function database() {
  return opening ||= new Promise((resolve,reject) => {
    const req=indexedDB.open(NAME,1);
    req.onupgradeneeded=()=>{req.result.createObjectStore('items',{keyPath:'id'});req.result.createObjectStore('meta');};
    req.onsuccess=()=>{const db=req.result;db.onversionchange=()=>{db.close();opening=null;};resolve(db);};
    req.onerror=()=>{opening=null;reject(req.error);};
  });
}
export async function transact(store, mode, work) {
  const db=await database();
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(store,mode);let result;
    try {result=work(tx.objectStore(store));} catch(error){tx.abort();reject(error);return;}
    tx.oncomplete=()=>resolve(result && typeof result==='object' && 'readyState' in result ? result.result : result);
    tx.onerror=tx.onabort=()=>reject(tx.error || new Error('LOCAL_STORAGE_FAILED'));
  });
}
export const getMeta=key=>transact('meta','readonly',store=>store.get(key));
export const putMeta=(key,value)=>transact('meta','readwrite',store=>store.put(value,key));
export const removeMeta=key=>transact('meta','readwrite',store=>store.delete(key));
export const getItem=id=>transact('items','readonly',store=>store.get(id));
export async function listItems() {return (await transact('items','readonly',s=>s.getAll())).filter(i=>!i.deletedAt).sort((a,b)=>a.order-b.order || a.capturedAt.localeCompare(b.capturedAt));}
export async function addItem(item) {
  const db=await database();
  return new Promise((resolve,reject)=>{
    const tx=db.transaction('items','readwrite'), store=tx.objectStore('items'), all=store.getAll();
    all.onsuccess=()=>{const active=all.result.filter(i=>!i.deletedAt);if(active.length>=1000){tx.abort();return;}store.put({...item,order:Math.max(0,...active.map(i=>i.order||0))+1});};
    tx.oncomplete=()=>resolve(item.id);tx.onerror=tx.onabort=()=>reject(tx.error||new Error('BASKET_FULL'));
  });
}
export async function updateItems(ids, update) {
  return transact('items','readwrite',store=>{for(const id of ids){const r=store.get(id);r.onsuccess=()=>{if(r.result)store.put({...r.result,...update});};}});
}
export async function reorder(ids) {
  return transact('items','readwrite',store=>ids.forEach((id,order)=>{const r=store.get(id);r.onsuccess=()=>{if(r.result)store.put({...r.result,order});};}));
}
export async function purgeDeleted() {
  return transact('items','readwrite',store=>{const req=store.openCursor();req.onsuccess=()=>{const cursor=req.result;if(!cursor)return;if(cursor.value.deletedAt && Date.now()-cursor.value.deletedAt>60_000)cursor.delete();cursor.continue();};});
}
